module.exports = {
    database: 'mongodb+srv://root:root@cluster0.latls.mongodb.net/BooksDB?retryWrites=true&w=majority'
}